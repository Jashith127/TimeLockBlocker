"use strict";

// ── MV3 Service Worker ────────────────────────────────────────────────────────
// Blocking is handled via declarativeNetRequest dynamic rules.
// Rules redirect blocked domains to block.html with ?u= (blockUntil ms) &h= (host).
// State is always reloaded from storage on SW wake since SWs can be killed anytime.

// ── In-memory cache (rebuilt from storage on each SW wake) ───────────────────
let blockedSites  = [];
let blockUntil    = 0;
let customPresets = [];
let userPin       = null;

// ── Helpers ───────────────────────────────────────────────────────────────────
function getHostname(url) {
  try { return new URL(url).hostname.replace(/^www\./, "").toLowerCase(); }
  catch (_) { return null; }
}

function isTimerActive() {
  return Date.now() < blockUntil;
}

// ── Load all state from storage into memory ───────────────────────────────────
async function loadState() {
  const data = await chrome.storage.local.get(["blockedSites", "blockUntil", "customPresets", "userPin"]);
  blockedSites  = Array.isArray(data.blockedSites)  ? data.blockedSites  : [];
  blockUntil    = typeof data.blockUntil === "number" ? data.blockUntil  : 0;
  customPresets = Array.isArray(data.customPresets) ? data.customPresets : [];
  userPin       = typeof data.userPin === "string"  ? data.userPin       : null;
}

// ── Sync declarativeNetRequest dynamic rules to current state ─────────────────
// When timer is active: add one redirect rule per blocked domain.
// When timer is not active: remove all dynamic rules.
async function syncRules() {
  const existing   = await chrome.declarativeNetRequest.getDynamicRules();
  const removeIds  = existing.map(r => r.id);

  if (!isTimerActive() || blockedSites.length === 0) {
    if (removeIds.length > 0) {
      await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds: removeIds });
    }
    return;
  }

  const blockPageBase = chrome.runtime.getURL("block.html")
    + "?u=" + String(blockUntil);

  const addRules = [];
  let ruleId = 1;

  for (const site of blockedSites) {
    const domain = site.replace(/^www\./, "").toLowerCase().trim();
    if (!domain || domain.indexOf(".") === -1) { continue; }

    // One rule matches the domain and all its subdomains via requestDomains
    addRules.push({
      id:       ruleId++,
      priority: 1,
      action: {
        type: "redirect",
        redirect: { url: blockPageBase + "&h=" + encodeURIComponent(domain) }
      },
      condition: {
        requestDomains: [domain],
        resourceTypes:  ["main_frame"]
      }
    });
  }

  await chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: removeIds,
    addRules:      addRules
  });
}

// ── Schedule an alarm to clear rules exactly when the timer expires ───────────
async function scheduleExpiryAlarm() {
  await chrome.alarms.clearAll();
  if (isTimerActive()) {
    chrome.alarms.create("expiry", { when: blockUntil });
  }
}

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name !== "expiry") { return; }
  await loadState();
  if (!isTimerActive()) {
    await syncRules(); // removes all block rules
  }
});

// ── Reload tabs whose domain is now blocked ───────────────────────────────────
async function reloadBlockedTabs() {
  const tabs = await chrome.tabs.query({});
  for (const tab of tabs) {
    if (!tab.url) { continue; }
    const host = getHostname(tab.url);
    if (!host) { continue; }
    const blocked = blockedSites.some(site => {
      const s = site.replace(/^www\./, "").toLowerCase().trim();
      return host === s || host.endsWith("." + s);
    });
    if (blocked) { chrome.tabs.reload(tab.id); }
  }
}

// ── Message handler ───────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {

  if (msg.type === "SET_TIMER") {
    (async () => {
      await loadState();
      const now   = Date.now();
      const until = now + msg.duration;
      blockUntil  = until;
      await chrome.storage.local.set({ blockUntil: until, blockStart: now });
      await syncRules();
      await scheduleExpiryAlarm();
      if (msg.reloadTabs !== false) { await reloadBlockedTabs(); }
      sendResponse({ success: true });
    })();
    return true;
  }

  if (msg.type === "GET_STATE") {
    (async () => {
      await loadState();
      sendResponse({
        blockUntil:    blockUntil,
        blockedSites:  blockedSites,
        customPresets: customPresets,
        hasPin:        userPin !== null,
        timerActive:   isTimerActive(),
        now:           Date.now()
      });
    })();
    return true;
  }

  if (msg.type === "SAVE_PRESETS") {
    if (!Array.isArray(msg.presets)) { sendResponse({ success: false }); return; }
    customPresets = msg.presets;
    chrome.storage.local.set({ customPresets: msg.presets });
    sendResponse({ success: true });
    return;
  }

  if (msg.type === "SAVE_BLOCKLIST") {
    (async () => {
      await loadState();
      blockedSites = Array.isArray(msg.sites) ? msg.sites : [];
      await chrome.storage.local.set({ blockedSites: blockedSites });
      await syncRules();
      sendResponse({ success: true });
    })();
    return true;
  }

  if (msg.type === "SET_PIN") {
    (async () => {
      await loadState();
      if (isTimerActive()) {
        sendResponse({ success: false, error: "Cannot change PIN while a timer is active." });
        return;
      }
      if (typeof msg.newPin !== "string" || !/^\d{4}$/.test(msg.newPin)) {
        sendResponse({ success: false, error: "Invalid PIN format." });
        return;
      }
      userPin = msg.newPin;
      await chrome.storage.local.set({ userPin: msg.newPin });
      sendResponse({ success: true });
    })();
    return true;
  }

  if (msg.type === "VERIFY_PIN") {
    (async () => {
      await loadState();
      sendResponse({ valid: msg.pin === userPin });
    })();
    return true;
  }
});

// ── Keep cache fresh when storage changes from other contexts ─────────────────
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") { return; }
  if (changes.blockedSites)            { blockedSites  = changes.blockedSites.newValue  || []; }
  if (changes.blockUntil)              { blockUntil    = changes.blockUntil.newValue    || 0;  }
  if (changes.customPresets)           { customPresets = changes.customPresets.newValue || []; }
  if (changes.userPin !== undefined)   { userPin       = changes.userPin.newValue || null;     }
});

// ── Lifecycle ─────────────────────────────────────────────────────────────────
chrome.runtime.onInstalled.addListener(async () => {
  await loadState();
  await syncRules();
  await scheduleExpiryAlarm();
});

chrome.runtime.onStartup.addListener(async () => {
  await loadState();
  await syncRules();
  await scheduleExpiryAlarm();
});

// Always load state when the SW wakes
loadState();

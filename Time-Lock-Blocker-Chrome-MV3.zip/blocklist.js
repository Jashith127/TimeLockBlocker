"use strict";

// ── State ─────────────────────────────────────────────────────────────────────
let sites          = [];
let timerActive    = false;
let blockUntil     = 0;
let pinBuffer      = "";
let pinCallback    = null;
let bannerInterval = null;

// ── Helpers ───────────────────────────────────────────────────────────────────
function parseDomain(raw) {
  return (raw || "").trim()
    .toLowerCase()
    .replace(/^https?:\/\//, "")
    .replace(/^www\./, "")
    .replace(/\/.*$/, "");
}

function isValidDomain(d) {
  return d.length > 2 && d.indexOf(".") !== -1;
}

function pad(n) { return (n < 10 ? "0" : "") + String(n); }

function fmtCountdown(ms) {
  if (ms <= 0) { return "00:00:00"; }
  const s = Math.ceil(ms / 1000);
  return pad(Math.floor(s / 3600)) + ":" +
         pad(Math.floor((s % 3600) / 60)) + ":" +
         pad(s % 60);
}

function el(id) { return document.getElementById(id); }

let msgTimer = null;
function showMsg(msg, ok) {
  const e = el("sMsg");
  e.textContent = msg;
  e.style.color = (ok === false) ? "#e03040" : "#39ff14";
  clearTimeout(msgTimer);
  msgTimer = setTimeout(() => { e.textContent = ""; }, 3000);
}

function updateCount() {
  el("cntEl").textContent = sites.length + " domain" + (sites.length !== 1 ? "s" : "");
}

// ── Render site list ──────────────────────────────────────────────────────────
function renderList() {
  const list = el("siteList");
  while (list.firstChild) { list.removeChild(list.firstChild); }

  if (sites.length === 0) {
    const empty = document.createElement("div");
    empty.className = "empty-msg";
    empty.textContent = "No sites blocked yet.";
    list.appendChild(empty);
    updateCount();
    return;
  }

  sites.forEach((site, i) => {
    const row    = document.createElement("div");
    row.className = "site-item";

    const name    = document.createElement("span");
    name.className = "site-name";
    name.textContent = site;

    const delBtn  = document.createElement("button");
    delBtn.className = timerActive ? "site-del locked" : "site-del";
    delBtn.textContent = timerActive ? "\uD83D\uDD12 REMOVE" : "REMOVE";

    delBtn.addEventListener("click", () => {
      if (timerActive) {
        openPinModal(
          "UNLOCK TO REMOVE",
          "Timer is active. Enter your PIN to remove this site.",
          () => { removeSite(i); }
        );
      } else {
        removeSite(i);
      }
    });

    row.appendChild(name);
    row.appendChild(delBtn);
    list.appendChild(row);
  });

  updateCount();
}

function removeSite(idx) {
  sites.splice(idx, 1);
  saveSites();
  renderList();
  showMsg("\u2713 Site removed.");
}

// ── Persist via background so DNR rules stay in sync ─────────────────────────
function saveSites() {
  chrome.runtime.sendMessage({ type: "SAVE_BLOCKLIST", sites: sites });
}

// ── Add site ──────────────────────────────────────────────────────────────────
function addSite() {
  const raw = el("addInput").value;
  const d   = parseDomain(raw);

  if (!isValidDomain(d)) { showMsg("! Invalid domain.", false); return; }
  if (sites.indexOf(d) !== -1) { showMsg("! Already in list.", false); return; }

  sites.push(d);
  saveSites();
  renderList();
  el("addInput").value = "";
  showMsg("\u2713 Added " + d);
}

el("addBtn").addEventListener("click", addSite);
el("addInput").addEventListener("keydown", e => { if (e.key === "Enter") { addSite(); } });

// ── Clear all — inline confirm instead of window.confirm ─────────────────────
el("clrBtn").addEventListener("click", () => {
  if (timerActive) {
    openPinModal(
      "UNLOCK TO CLEAR",
      "Timer is active. Enter your PIN to clear all sites.",
      () => { doClearAll(); }
    );
    return;
  }
  // Show inline confirm bar instead of window.confirm (blocked in MV3 pages)
  openConfirmBar("Clear all blocked sites?", () => { doClearAll(); });
});

function doClearAll() {
  sites = [];
  saveSites();
  renderList();
  showMsg("\u2713 List cleared.");
}

// ── Inline confirm bar (replaces window.confirm) ──────────────────────────────
let confirmCallback = null;

function openConfirmBar(question, onYes) {
  confirmCallback = onYes;
  el("confirmQuestion").textContent = question;
  el("confirmBar").classList.add("show");
}

el("confirmYes").addEventListener("click", () => {
  el("confirmBar").classList.remove("show");
  if (confirmCallback) { confirmCallback(); }
  confirmCallback = null;
});

el("confirmNo").addEventListener("click", () => {
  el("confirmBar").classList.remove("show");
  confirmCallback = null;
});

// ── Banner countdown ──────────────────────────────────────────────────────────
function updateBanner() {
  const rem = blockUntil - Date.now();
  if (rem > 0) {
    el("bannerCd").textContent = fmtCountdown(rem);
  } else {
    timerActive = false;
    el("timerBanner").classList.remove("show");
    clearInterval(bannerInterval);
    bannerInterval = null;
    renderList();
  }
}

function startBanner() {
  el("timerBanner").classList.add("show");
  clearInterval(bannerInterval);
  updateBanner();
  bannerInterval = setInterval(updateBanner, 500);
}

// ── PIN MODAL ─────────────────────────────────────────────────────────────────
function openPinModal(title, desc, onSuccess) {
  pinCallback = onSuccess;
  pinBuffer   = "";
  updateBListPinDots();
  el("pinTitle").textContent = title;
  el("pinDesc").textContent  = desc;
  el("pinErr").textContent   = "";
  el("pinModal").classList.add("open");
}

function closePinModal() {
  pinBuffer   = "";
  pinCallback = null;
  el("pinModal").classList.remove("open");
  el("pinErr").textContent = "";
  updateBListPinDots();
}

function updateBListPinDots() {
  for (let i = 0; i < 4; i++) {
    el("bpd" + i).classList.toggle("filled", i < pinBuffer.length);
  }
}

el("pinModal").querySelectorAll(".pin-key[data-d]").forEach(btn => {
  btn.addEventListener("mousedown", e => {
    e.preventDefault();
    if (pinBuffer.length >= 4) { return; }
    pinBuffer += btn.getAttribute("data-d");
    updateBListPinDots();
    el("pinErr").textContent = "";
    if (pinBuffer.length === 4) { submitPin(); }
  });
});

el("bpDel").addEventListener("mousedown", e => {
  e.preventDefault();
  pinBuffer = pinBuffer.slice(0, -1);
  updateBListPinDots();
});

el("bpClr").addEventListener("mousedown", e => {
  e.preventDefault();
  pinBuffer = "";
  updateBListPinDots();
});

el("pinSubmit").addEventListener("mousedown", e => {
  e.preventDefault();
  submitPin();
});

el("pinClose").addEventListener("click", closePinModal);
el("pinModal").addEventListener("click", e => {
  if (e.target === el("pinModal")) { closePinModal(); }
});

function submitPin() {
  if (pinBuffer.length < 4) { el("pinErr").textContent = "Enter all 4 digits."; return; }
  chrome.runtime.sendMessage({ type: "VERIFY_PIN", pin: pinBuffer }).then(res => {
    if (res && res.valid) {
      const cb = pinCallback;
      closePinModal();
      if (cb) { cb(); }
    } else {
      el("pinErr").textContent = "\u2715 Incorrect PIN.";
      pinBuffer = "";
      updateBListPinDots();
    }
  });
}

// ── Init ──────────────────────────────────────────────────────────────────────
chrome.runtime.sendMessage({ type: "GET_STATE" }).then(state => {
  sites       = Array.isArray(state.blockedSites) ? state.blockedSites : [];
  timerActive = state.timerActive || false;
  blockUntil  = state.blockUntil  || 0;
  renderList();
  if (timerActive) { startBanner(); }
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") { return; }
  if (changes.blockedSites) {
    sites = changes.blockedSites.newValue || [];
    renderList();
  }
  if (changes.blockUntil) {
    blockUntil  = changes.blockUntil.newValue || 0;
    timerActive = blockUntil > Date.now();
    if (timerActive) { startBanner(); }
    else {
      el("timerBanner").classList.remove("show");
      clearInterval(bannerInterval);
      bannerInterval = null;
      renderList();
    }
  }
});

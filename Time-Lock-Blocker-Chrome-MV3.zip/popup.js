"use strict";

// ── State ─────────────────────────────────────────────────────────────────────
var DEFAULT_PRESETS = [
  { label: "10 mins", ms: 10 * 60 * 1000 },
  { label: "30 mins", ms: 30 * 60 * 1000 },
  { label: "01 hour", ms:  1 * 60 * 60 * 1000 },
  { label: "02 hours",ms:  2 * 60 * 60 * 1000 },
  { label: "03 hours",ms:  3 * 60 * 60 * 1000 }
];

var presets     = DEFAULT_PRESETS.slice();
var selIdx      = -1;
var blockUntil  = 0;
var timerActive = false;
var cdInterval  = null;
var currentUnit = "minutes"; // tracks custom dropdown value

// ── Helpers ───────────────────────────────────────────────────────────────────
function parseDuration(raw, unit) {
  raw = (raw || "").trim();
  if (!raw) { return null; }

  var m = raw.match(
    /^(?:(\d+(?:\.\d+)?)\s*h(?:(?:ou)?r?s?)?\s*)?(?:(\d+(?:\.\d+)?)\s*m(?:in(?:ute)?s?)?\s*)?(?:(\d+(?:\.\d+)?)\s*s(?:ec(?:ond)?s?)?)?$/i
  );
  if (m && (m[1] || m[2] || m[3])) {
    var total = (parseFloat(m[1] || 0) * 3600) +
                (parseFloat(m[2] || 0) * 60)   +
                 parseFloat(m[3] || 0);
    return total > 0 ? Math.round(total * 1000) : null;
  }

  var n = parseFloat(raw);
  if (!isNaN(n) && n > 0) {
    if (unit === "hours")   { return Math.round(n * 3600000); }
    if (unit === "seconds") { return Math.round(n * 1000); }
    return Math.round(n * 60000);
  }
  return null;
}

function msToLabel(ms) {
  var h = Math.floor(ms / 3600000);
  var m = Math.floor((ms % 3600000) / 60000);
  var s = Math.floor((ms % 60000) / 1000);
  var parts = [];
  if (h) { parts.push(h + "h"); }
  if (m) { parts.push(m + "m"); }
  if (s) { parts.push(s + "s"); }
  return parts.join(" ") || "0m";
}

function pad(n) { return (n < 10 ? "0" : "") + String(n); }

function fmtHMS(ms) {
  if (ms <= 0) { return "00:00:00"; }
  var s = Math.ceil(ms / 1000);
  return pad(Math.floor(s / 3600)) + ":" + pad(Math.floor((s % 3600) / 60)) + ":" + pad(s % 60);
}

function el(id) { return document.getElementById(id); }

// ── Custom Unit Dropdown ──────────────────────────────────────────────────────
var unitDropdown = el("cUnitDropdown");
var unitDisplay  = el("cUnitDisplay");
var unitLabel    = el("cUnitLabel");

el("cUnitDisplay").addEventListener("click", function (e) {
  e.stopPropagation();
  unitDropdown.classList.toggle("open");
});

unitDropdown.querySelectorAll(".c-unit-opt").forEach(function (opt) {
  opt.addEventListener("click", function (e) {
    e.stopPropagation();
    currentUnit = opt.getAttribute("data-val");
    unitLabel.textContent = opt.textContent;
    unitDropdown.querySelectorAll(".c-unit-opt").forEach(function (o) {
      o.classList.toggle("selected", o === opt);
    });
    unitDropdown.classList.remove("open");
  });
});

document.addEventListener("click", function () {
  unitDropdown.classList.remove("open");
});

// ── Preset rendering ──────────────────────────────────────────────────────────
function renderPresets() {
  var grid = el("presetsGrid");
  while (grid.firstChild) { grid.removeChild(grid.firstChild); }

  presets.forEach(function(p, i) {
    var btn = document.createElement("button");
    btn.className = "preset-btn" + (i === selIdx ? " active" : "");
    btn.textContent = p.label || msToLabel(p.ms);
    btn.addEventListener("click", function() {
      selIdx = (selIdx === i) ? -1 : i;
      renderPresets();
    });
    grid.appendChild(btn);
  });
}

// ── Status bar countdown ──────────────────────────────────────────────────────
function tick() {
  var rem = blockUntil - Date.now();
  if (rem > 0) {
    el("sDot").classList.add("live");
    el("sTxt").textContent = "BLOCKING ACTIVE";
    el("sCd").textContent  = fmtHMS(rem);
  } else {
    el("sDot").classList.remove("live");
    el("sTxt").textContent = "INACTIVE \u2014 no timer running";
    el("sCd").textContent  = "";
    clearInterval(cdInterval);
    cdInterval = null;
  }
}

function startCD() {
  if (cdInterval) { clearInterval(cdInterval); }
  cdInterval = setInterval(tick, 500);
  tick();
}

// ── Confirm message ───────────────────────────────────────────────────────────
var confirmTimer = null;
function showConfirm(msg, isErr) {
  var cel = el("confirmMsg");
  cel.textContent = msg;
  cel.className = "confirm show" + (isErr ? " err" : "");
  clearTimeout(confirmTimer);
  confirmTimer = setTimeout(function() { cel.className = "confirm"; }, 3000);
}

// ── Custom time +/− ───────────────────────────────────────────────────────────
function step(dir) {
  var inp = el("cInput");
  var v   = parseFloat(inp.value) || 0;
  var s   = (currentUnit === "hours") ? 0.5 : (currentUnit === "seconds") ? 30 : 5;
  v = Math.max(0, v + dir * s);
  inp.value = (v % 1 === 0) ? String(v) : v.toFixed(1);
}

el("minusBtn").addEventListener("click", function() { step(-1); });
el("plusBtn").addEventListener("click",  function() { step(1);  });

// ── SET TIMER ─────────────────────────────────────────────────────────────────
el("setBtn").addEventListener("click", function() {
  var ms = (selIdx >= 0)
    ? presets[selIdx].ms
    : parseDuration(el("cInput").value, currentUnit);

  if (!ms || ms <= 0) {
    showConfirm("! Select a preset or enter a valid duration.", true);
    return;
  }

  chrome.runtime.sendMessage({ type: "SET_TIMER", duration: ms }).then(function() {
    blockUntil  = Date.now() + ms;
    timerActive = true;
    tick();
    startCD();
    showConfirm("\u2713 Timer set \u2014 blocking active.");
    selIdx = -1;
    renderPresets();
    el("cInput").value = "";
  });
});

// ── Block List ────────────────────────────────────────────────────────────────
el("blocklistBtn").addEventListener("click", function() {
  chrome.tabs.create({ url: chrome.runtime.getURL("blocklist.html") });
  window.close();
});

// ── Add current site button ───────────────────────────────────────────────────
var pendingHost = "";

el("addSiteBtn").addEventListener("click", function() {
  // If bar already open, close it
  if (el("addConfirmBar").classList.contains("show")) {
    el("addConfirmBar").classList.remove("show");
    pendingHost = "";
    return;
  }

  chrome.tabs.query({ active: true, currentWindow: true }).then(function(tabs) {
    if (!tabs || !tabs[0] || !tabs[0].url) {
      showConfirm("! Could not get current tab URL.", true);
      return;
    }
    var url = tabs[0].url;
    var host;
    try {
      host = new URL(url).hostname.replace(/^www\./, "").toLowerCase();
    } catch (_e) {
      showConfirm("! Invalid URL.", true);
      return;
    }
    if (!host) {
      showConfirm("! No valid host found.", true);
      return;
    }
    pendingHost = host;
    el("addConfirmHost").textContent = host;
    el("addConfirmBar").classList.add("show");
  });
});

el("addConfirmYes").addEventListener("click", function() {
  if (!pendingHost) { return; }
  var host = pendingHost;
  el("addConfirmBar").classList.remove("show");
  pendingHost = "";

  chrome.storage.local.get("blockedSites").then(function(data) {
    var list = Array.isArray(data.blockedSites) ? data.blockedSites : [];
    if (list.indexOf(host) !== -1) {
      showConfirm("! " + host + " is already blocked.", true);
      return;
    }
    list.push(host);
    chrome.storage.local.set({ blockedSites: list }).then(function() {
      showConfirm("\u2713 " + host + " added to block list.");
    });
  });
});

el("addConfirmNo").addEventListener("click", function() {
  el("addConfirmBar").classList.remove("show");
  pendingHost = "";
});

// ── SETTINGS MODAL ───────────────────────────────────────────────────────────
el("settingsBtn").addEventListener("click", function() {
  renderPresetEditor();
  el("presetModal").classList.add("open");
});

// ── Collapsible presets section ───────────────────────────────────────────────
var presetsCollapsed = false;
el("presetsToggle").addEventListener("click", function() {
  presetsCollapsed = !presetsCollapsed;
  var col = el("presetsCollapsible");
  var tog = el("presetsToggle");
  col.style.display = presetsCollapsed ? "none" : "";
  tog.classList.toggle("collapsed", presetsCollapsed);
});
el("presetModalX").addEventListener("click", function() { el("presetModal").classList.remove("open"); });
el("presetModal").addEventListener("click", function(e) {
  if (e.target === el("presetModal")) { el("presetModal").classList.remove("open"); }
});

var dragSrcIdx = null;

function syncEditorToPresets() {
  // Read current input values back into presets array before any re-render
  var inputs = el("presetList").querySelectorAll(".p-item input");
  inputs.forEach(function(inp, i) {
    if (presets[i]) { presets[i].label = inp.value; }
  });
}

function renderPresetEditor() {
  var list = el("presetList");
  while (list.firstChild) { list.removeChild(list.firstChild); }

  presets.forEach(function(p, i) {
    var row = document.createElement("div");
    row.className = "p-item";
    row.draggable = true;
    row.setAttribute("data-idx", i);

    // ── Drag handle ──
    var handle = document.createElement("span");
    handle.className = "p-drag";
    handle.textContent = "\u2807"; // ⠷ braille dots as grip icon
    handle.title = "Drag to reorder";

    // ── Text input ──
    var inp = document.createElement("input");
    inp.type = "text";
    inp.value = p.label || msToLabel(p.ms);
    inp.placeholder = "e.g. 45m | 1h 30m | 2h";
    // Prevent drag starting when user is selecting text in the input
    inp.addEventListener("mousedown", function(e) { e.stopPropagation(); });

    // ── Delete button ──
    var delBtn = document.createElement("button");
    delBtn.className = "p-del";
    delBtn.textContent = "\u2715";
    delBtn.addEventListener("click", (function(idx) {
      return function() {
        syncEditorToPresets();
        presets.splice(idx, 1);
        if (selIdx >= presets.length) { selIdx = -1; }
        renderPresetEditor();
        renderPresets();
      };
    }(i)));

    // ── Drag events ──
    row.addEventListener("dragstart", function(e) {
      syncEditorToPresets();
      dragSrcIdx = parseInt(row.getAttribute("data-idx"), 10);
      row.classList.add("dragging");
      e.dataTransfer.effectAllowed = "move";
    });

    row.addEventListener("dragend", function() {
      row.classList.remove("dragging");
      el("presetList").querySelectorAll(".p-item").forEach(function(r) {
        r.classList.remove("drag-over");
      });
    });

    row.addEventListener("dragover", function(e) {
      e.preventDefault();
      e.dataTransfer.dropEffect = "move";
      el("presetList").querySelectorAll(".p-item").forEach(function(r) {
        r.classList.remove("drag-over");
      });
      row.classList.add("drag-over");
    });

    row.addEventListener("drop", function(e) {
      e.preventDefault();
      var targetIdx = parseInt(row.getAttribute("data-idx"), 10);
      if (dragSrcIdx === null || dragSrcIdx === targetIdx) { return; }
      // Reorder
      var moved = presets.splice(dragSrcIdx, 1)[0];
      presets.splice(targetIdx, 0, moved);
      if (selIdx === dragSrcIdx) {
        selIdx = targetIdx;
      } else if (dragSrcIdx < targetIdx && selIdx > dragSrcIdx && selIdx <= targetIdx) {
        selIdx--;
      } else if (dragSrcIdx > targetIdx && selIdx >= targetIdx && selIdx < dragSrcIdx) {
        selIdx++;
      }
      dragSrcIdx = null;
      renderPresetEditor();
      renderPresets();
    });

    row.appendChild(handle);
    row.appendChild(inp);
    row.appendChild(delBtn);
    list.appendChild(row);
  });
}

el("addPreset").addEventListener("click", function() {
  syncEditorToPresets();
  presets.push({ label: "15 mins", ms: 15 * 60 * 1000 });
  renderPresetEditor();
  renderPresets();
});

el("savePresets").addEventListener("click", function() {
  var inputs  = el("presetList").querySelectorAll(".p-item input");
  var updated = [];
  var ok      = true;

  inputs.forEach(function(inp) {
    var ms = parseDuration(inp.value.trim(), "minutes");
    if (!ms) {
      inp.style.borderColor = "#e03040";
      ok = false;
    } else {
      inp.style.borderColor = "";
      updated.push({ label: inp.value.trim(), ms: ms });
    }
  });

  if (!ok) { return; }

  presets = updated;
  if (selIdx >= presets.length) { selIdx = -1; }

  chrome.runtime.sendMessage({ type: "SAVE_PRESETS", presets: presets }).then(function() {
    renderPresets();
    el("presetModal").classList.remove("open");
  });
});

// ── CHANGE PIN MODAL ──────────────────────────────────────────────────────────
var pinBuf   = "";
var pinStep  = "new";
var pinFirst = "";

function openPinModal() {
  pinBuf = ""; pinStep = "new"; pinFirst = "";
  updatePinDots();
  el("pinModalTitle").textContent = "CHANGE PIN";
  el("pinErr").textContent = "";

  if (timerActive) {
    el("pinModalDesc").textContent  = "You cannot change your PIN while a timer is active.";
    el("pinSubmit").style.display   = "none";
    el("pinModal").querySelectorAll(".pin-key").forEach(function(k) { k.style.display = "none"; });
  } else {
    el("pinModalDesc").textContent  = "Enter a new 4-digit PIN.";
    el("pinSubmit").style.display   = "";
    el("pinModal").querySelectorAll(".pin-key").forEach(function(k) { k.style.display = ""; });
  }
  el("pinModal").classList.add("open");
}

function closePinModal() {
  pinBuf = "";
  el("pinModal").classList.remove("open");
  updatePinDots();
}

function updatePinDots() {
  for (var i = 0; i < 4; i++) {
    el("pd" + i).classList.toggle("filled", i < pinBuf.length);
  }
}

el("changePinBtn").addEventListener("click", openPinModal);
el("pinModalX").addEventListener("click", closePinModal);
el("pinModal").addEventListener("click", function(e) {
  if (e.target === el("pinModal")) { closePinModal(); }
});

el("pinModal").querySelectorAll(".pin-key[data-p]").forEach(function(btn) {
  btn.addEventListener("mousedown", function(e) {
    e.preventDefault();
    if (pinBuf.length >= 4) { return; }
    pinBuf += btn.getAttribute("data-p");
    updatePinDots();
    el("pinErr").textContent = "";
  });
});

el("pDel").addEventListener("mousedown", function(e) {
  e.preventDefault();
  pinBuf = pinBuf.slice(0, -1);
  updatePinDots();
});

el("pClr").addEventListener("mousedown", function(e) {
  e.preventDefault();
  pinBuf = "";
  updatePinDots();
});

el("pinSubmit").addEventListener("mousedown", function(e) {
  e.preventDefault();
  submitChangePin();
});

function submitChangePin() {
  if (pinBuf.length < 4) {
    el("pinErr").textContent = "Enter all 4 digits.";
    return;
  }
  if (pinStep === "new") {
    pinFirst = pinBuf;
    pinBuf   = "";
    pinStep  = "confirm";
    updatePinDots();
    el("pinModalDesc").textContent = "Confirm your new PIN.";
    el("pinErr").textContent = "";
  } else {
    if (pinBuf !== pinFirst) {
      el("pinErr").textContent = "PINs don\u2019t match. Try again.";
      pinBuf = ""; pinStep = "new"; pinFirst = "";
      updatePinDots();
      el("pinModalDesc").textContent = "Enter a new 4-digit PIN.";
      return;
    }
    chrome.runtime.sendMessage({ type: "SET_PIN", newPin: pinBuf }).then(function(res) {
      if (res && res.success === false) {
        el("pinErr").textContent = res.error || "Error setting PIN.";
      } else {
        closePinModal();
        showConfirm("\u2713 PIN updated.");
      }
    });
  }
}

// ── FIRST-INSTALL SETUP ───────────────────────────────────────────────────────
var setupBuf   = "";
var setupStep  = "set";
var setupFirst = "";

function showSetup() { el("setupOverlay").classList.add("show"); }
function hideSetup() { el("setupOverlay").classList.remove("show"); }

function updateSetupDots() {
  for (var i = 0; i < 4; i++) {
    el("sd" + i).classList.toggle("filled", i < setupBuf.length);
  }
}

function updateSetupProgress(step) {
  el("sp0").classList.toggle("on", step >= 0);
  el("sp1").classList.toggle("on", step >= 1);
}

document.querySelectorAll(".sk[data-sd]").forEach(function(btn) {
  btn.addEventListener("mousedown", function(e) {
    e.preventDefault();
    if (setupBuf.length >= 4) { return; }
    setupBuf += btn.getAttribute("data-sd");
    updateSetupDots();
    el("setupErr").textContent = "";
  });
});

el("sdDel").addEventListener("mousedown", function(e) {
  e.preventDefault();
  setupBuf = setupBuf.slice(0, -1);
  updateSetupDots();
});

el("sdEnter").addEventListener("mousedown", function(e) {
  e.preventDefault();
  handleSetupEnter();
});

document.addEventListener("keydown", function(e) {
  if (!el("setupOverlay").classList.contains("show")) { return; }
  if (e.key >= "0" && e.key <= "9" && setupBuf.length < 4) {
    setupBuf += e.key;
    updateSetupDots();
    el("setupErr").textContent = "";
  } else if (e.key === "Backspace") {
    setupBuf = setupBuf.slice(0, -1);
    updateSetupDots();
  } else if (e.key === "Enter") {
    handleSetupEnter();
  }
});

function handleSetupEnter() {
  if (setupBuf.length < 4) {
    el("setupErr").textContent = "Enter all 4 digits first.";
    return;
  }
  if (setupStep === "set") {
    setupFirst = setupBuf;
    setupBuf   = "";
    setupStep  = "confirm";
    updateSetupDots();
    updateSetupProgress(1);
    el("setupStepLabel").textContent = "Step 2 of 2 \u2014 Confirm your PIN";
    el("setupErr").textContent = "";
  } else {
    if (setupBuf !== setupFirst) {
      el("setupErr").textContent = "PINs don\u2019t match. Try again.";
      setupBuf = ""; setupStep = "set"; setupFirst = "";
      updateSetupDots();
      updateSetupProgress(0);
      el("setupStepLabel").textContent = "Step 1 of 2 \u2014 Enter a 4-digit PIN";
      return;
    }
    chrome.runtime.sendMessage({ type: "SET_PIN", newPin: setupBuf }).then(function() {
      hideSetup();
    });
  }
}

// ── RESIZE GRIP (vertical only) ──────────────────────────────────────────────
(function () {
  var MIN_H = 300;
  var MAX_H = 700;

  function setHeight(h) {
    ["resizeWrapper", "setupResizeWrapper"].forEach(function(id) {
      var el2 = document.getElementById(id);
      if (el2) { el2.style.height = h + "px"; }
    });
  }

  // Restore saved height
  try {
    var savedH = sessionStorage.getItem("tlb-h");
    if (savedH) { setHeight(parseFloat(savedH)); }
  } catch (_) {}

  var vGrip = el("resizeGrip");
  if (!vGrip) { return; }

  var startY = 0, startH = 0;

  vGrip.addEventListener("pointerdown", function (e) {
    e.preventDefault();
    vGrip.setPointerCapture(e.pointerId);
    startY = e.clientY;
    var cur = document.getElementById("resizeWrapper") || document.getElementById("setupResizeWrapper");
    startH = cur ? cur.offsetHeight : 420;
    vGrip.style.background = "var(--bg4)";
  });

  vGrip.addEventListener("pointermove", function (e) {
    if (!vGrip.hasPointerCapture(e.pointerId)) { return; }
    var newH = Math.min(MAX_H, Math.max(MIN_H, startH + (e.clientY - startY)));
    setHeight(newH);
  });

  vGrip.addEventListener("pointerup", function (e) {
    if (!vGrip.hasPointerCapture(e.pointerId)) { return; }
    vGrip.releasePointerCapture(e.pointerId);
    vGrip.style.background = "";
    var cur = document.getElementById("resizeWrapper") || document.getElementById("setupResizeWrapper");
    try { sessionStorage.setItem("tlb-h", cur ? cur.offsetHeight : 420); } catch (_) {}
  });
}());

// ── INIT ──────────────────────────────────────────────────────────────────────
chrome.runtime.sendMessage({ type: "GET_STATE" }).then(function(state) {
  blockUntil  = state.blockUntil  || 0;
  timerActive = state.timerActive || false;

  if (Array.isArray(state.customPresets) && state.customPresets.length > 0) {
    presets = state.customPresets;
  }

  renderPresets();
  tick();
  if (blockUntil > Date.now()) { startCD(); }

  if (!state.hasPin) { showSetup(); }
});

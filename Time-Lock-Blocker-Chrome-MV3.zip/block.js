/*
 * block.js — runs inside block.html (web_accessible_resource).
 * browser.* API is NOT available here.
 * Parameters from background.js via URL:
 *   ?u=<blockUntil_ms>  &h=<hostname>  &r=<encoded_original_url>
 */
"use strict";

(function () {
  var params    = new URLSearchParams(window.location.search);
  var until     = parseInt(params.get("u") || "0", 10);
  var host      = params.get("h") ? decodeURIComponent(params.get("h")) : "";
  var returnUrl = params.get("r") ? decodeURIComponent(params.get("r")) : "";

  // Populate domain text safely
  var domEl = document.getElementById("domValue");
  if (domEl) { domEl.textContent = host || "this site"; }

  var dispEl  = document.getElementById("tDisp");
  var fillEl  = document.getElementById("pFill");
  var cardEl  = document.getElementById("refreshCard");
  var btnEl   = document.getElementById("refreshBtn");

  if (!dispEl || !fillEl) { return; }

  var startMs = Date.now();
  var totalMs = until - startMs;

  function pad(n) { return (n < 10 ? "0" : "") + n; }

  function formatHMS(ms) {
    if (ms <= 0) { return "00:00:00"; }
    var s = Math.ceil(ms / 1000);
    return pad(Math.floor(s / 3600)) + ":" + pad(Math.floor((s % 3600) / 60)) + ":" + pad(s % 60);
  }

  function onExpired() {
    dispEl.textContent = "00:00:00";
    fillEl.style.width = "0%";
    if (cardEl) { cardEl.style.display = "block"; }
  }

  // Refresh button — navigate back to original site
  if (btnEl) {
    btnEl.addEventListener("click", function () {
      if (returnUrl) {
        window.location.href = returnUrl;
      } else {
        window.history.back();
      }
    });
  }

  // Already expired on load
  if (!until || until <= Date.now()) {
    onExpired();
    return;
  }

  var handle = setInterval(function () {
    var rem = until - Date.now();
    if (rem > 0) {
      dispEl.textContent = formatHMS(rem);
      if (totalMs > 0) {
        fillEl.style.width = Math.max(0, Math.min(100, (rem / totalMs) * 100)).toFixed(2) + "%";
      }
    } else {
      clearInterval(handle);
      onExpired();
    }
  }, 500);

  // Initial render
  dispEl.textContent = formatHMS(until - Date.now());
}());
